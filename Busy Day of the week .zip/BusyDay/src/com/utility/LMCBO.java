package com.utility;
import com.ui.*;

import java.util.*;
import java.util.Map.Entry;

public class LMCBO {
	
private List<String> appointmentDetailsList = new ArrayList<String>();
	
	
	public List<String> getAppointmentDetailsList() {
		return appointmentDetailsList;
	}


	public void setAppointmentDetailsList(List<String> appointmentDetailsList) {
		this.appointmentDetailsList = appointmentDetailsList;
	}


	//This method should add the appointmentDay passed as argument into the appointmentDetailsList
	public void addAppointmentDayDetails (String appointmentDay)
	{
		//type your code here
		appointmentDetailsList.add(appointmentDay);
		setAppointmentDetailsList(appointmentDetailsList);
	}
	
	
	/* This method should return the maximum number of appointments made based on values available in the appointmentDetailsList 
	
	For Example:
	 if the list contains the following values as [Saturday,Friday,Saturday,Saturday,Monday]
	 the output should be Saturday

	 */
	public int findAppointmentCount(String findDay) 
	{  int count =0;
		
		// type your code here
		if(getAppointmentDetailsList().isEmpty()!=true)
	{
		for (String day : appointmentDetailsList) 
		{
			if(day.equalsIgnoreCase(findDay))
			{
				count++;
			}
		}
		return count;
	}
		return -1;
	}
}
