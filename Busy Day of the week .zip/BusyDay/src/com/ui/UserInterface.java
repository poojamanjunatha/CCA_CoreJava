package com.ui;

import com.utility.*;
import java.util.*;

public class UserInterface 
{

		public static void main(String[] args)
		{
			Scanner sc =new Scanner(System.in);
			//type your code here
			
			LMCBO l = new LMCBO();
		boolean b = true;
		while (b) {
			System.out.println("1. Add appointment details\n2. Day to find Count\n3. Exit");
			System.out.println("Enter your choice");
			int n = sc.nextInt();
			switch (n) {
			case 1:
				System.out.println("Enter the patient name");
				String name = sc.next();
				System.out.println("Enter the requesting appointment day");
				String day = sc.next();
				l.addAppointmentDayDetails(day);
				break;

			case 2:
				System.out.println("Enter the day to find the count");
				String findDay = sc.next();
				System.out.println(l.findAppointmentCount(findDay));
				break;

			case 3:
				System.out.println("Thank you for using the Application");
				b = false;
				break;

			default:
				break;
			}
		}
		}

	}

