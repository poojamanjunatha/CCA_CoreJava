import java.util.Scanner;

public class Main {
	
	static int roomNo;
	static String phone;

	public static void main(String[] args) {

		Hosteller h = getHostellerDetails();
		System.out.println(h.toString());
	}

	public static Hosteller getHostellerDetails() {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Details:");
		System.out.println("Student Id");
		int sid = scanner.nextInt();

		System.out.println("Student Name");
		String sname = scanner.next();

		System.out.println("Department Id");
		int did = scanner.nextInt();

		System.out.println("Gender");
		String gender = scanner.next();
		
		System.out.println("Phone Number");
		phone = scanner.next();
		
		System.out.println("Hostel Name");
		String hostelName = scanner.next();
		
		System.out.println("Room Number");
		roomNo = scanner.nextInt();
		
		System.out.println("Modify Room Number(Y/N)");
		String modifyRoom = scanner.next();
		if(modifyRoom.equalsIgnoreCase("Y")) {
			System.out.println("New Room Number");
			roomNo = scanner.nextInt();
		}
		
		System.out.println("Modify Phone Number(Y/N)");
		String modifyPhone = scanner.next();
		if(modifyPhone.equalsIgnoreCase("Y")) {
			System.out.println("New Phone Number");
			phone = scanner.next();
		}
		
		Hosteller h = new Hosteller(hostelName, roomNo, sid, sname, did, gender, phone);
		return h;
	}
}
