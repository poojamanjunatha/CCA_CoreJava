public class Hosteller extends Student {

	private String hostelName;
	private int roomNumber;

	public String getHostelName() {
		return hostelName;
	}

	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}

	public int getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public Hosteller(String hostelName, int roomNumber, int studentId, String name, int departmentId, String gender,
			String phone) {
		super(studentId, name, departmentId, gender, phone);
		this.hostelName = hostelName;
		this.roomNumber = roomNumber;
	}

	public Hosteller() {

	}

	public String toString() {
		System.out.println("The Student Details");

		String result = studentId + " " + name + " " + departmentId + " " + gender + " " + phone + " " + hostelName
				+ " " + roomNumber;
		return result;
	}
}
