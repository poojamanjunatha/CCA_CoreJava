
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class School {
	
	public Student viewStudent(int sid) throws ClassNotFoundException, SQLException
	{
		Statement stmt = null;
		Student studentObj = new Student();

		String query = "select * from student where studId  =" + sid + ";";

		stmt = DB.getConnection().createStatement();
		ResultSet result = stmt.executeQuery(query);

		while (result.next()) {
			studentObj.setStudId(result.getInt(1));
			studentObj.setStudName(result.getString(2));
			studentObj.setTotal(result.getInt(3));

		}
		DB.getConnection().close();
		return studentObj;
	}
}

