
public class TaxableItem extends Item
{
	private float GST;
	private float taxAmount;
	


	public float getGST() {
		return GST;
	}

	public void setGST(float gST) {
		this.GST = gST;
	}

	public float getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(float taxAmount) {
		this.taxAmount = taxAmount;
	}
	
	public int findTaxAmount()
	{
		if(getItemCost()>0 && GST>0)
		{
			taxAmount=(getItemCost()*(GST/100));
			setTotalCost(getItemCost()+taxAmount);
			return 1;
		}
		else
			return -1;
	}
}
