

import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Item Name:");
		String itemName = sc.nextLine();
		System.out.println("Enter the Item Cost:");
		float itemCost = sc.nextFloat();
		System.out.println("Enter the GST:");
		float gST = sc.nextFloat();
		
		TaxableItem t=new TaxableItem();
		t.setGST(gST);
		t.setItemName(itemName);
		t.setItemCost(itemCost);
		
		int output=t.findTaxAmount();
		if(output==1)
		{
			System.out.println("Total Cost:"+t.getTotalCost());
		}
		else
		{
			System.out.println(output);
		}
		sc.close();
	}

}
