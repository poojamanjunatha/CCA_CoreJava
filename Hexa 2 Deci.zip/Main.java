import java.util.Scanner;
public class Main {
	static int hexadecimalToDecimal(String hexVal) 
    {    
        int len = hexVal.length(); 
       
        
				
   	
        int base = 1; 
       
        int dec_val = 0; 
       
        
        if(len<4 || len>=6 ) {
 			System.out.println(hexVal+" is a "+len+" digit input");
 			System.exit(0);
 		}
        
        for (int i=len-1; i>=0; i--) 
        {    
        	
        	
        	if (hexVal.charAt(i) > 'F' && hexVal.charAt(i) <= 'Z') {
        		System.out.println(hexVal+" is Invalid");
        		System.exit(0);
        	}
        	
            if (hexVal.charAt(i) >= '0' && hexVal.charAt(i) <= '9') 
            { 
                dec_val += (hexVal.charAt(i) - 48)*base; 
                   
                // incrementing base by power 
                base = base * 16; 
            } 
   
            // if character lies in 'A'-'F' , converting  
            // it to integral 10 - 15 by subtracting 55  
            // from ASCII value 
            else if (hexVal.charAt(i) >= 'A' && hexVal.charAt(i) <= 'F') 
            { 
                dec_val += (hexVal.charAt(i) - 55)*base; 
           
                // incrementing base by power 
                base = base*16; 
            } 
        } 
        return dec_val; 
    } 
      
    // driver program 
    public static void main (String[] args)  
    { 
    	Scanner sc=new Scanner(System.in);
        String hexNum=sc.next();    

			
        System.out.println(hexadecimalToDecimal(hexNum)); 
    } 
			
		
		
    }

