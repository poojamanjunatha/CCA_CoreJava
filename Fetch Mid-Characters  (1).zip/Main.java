import java.util.Scanner;

public class Main
{
    public static void main(String args[])
    {
       Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string:");
		String s = sc.nextLine();
		if (s.length() > 2) {
			StringBuffer sb = new StringBuffer();
			boolean flag = true;
			for (int i = 0; i < s.length(); i++) {
				if (!Character.isAlphabetic(s.charAt(i))) {
					String[] sa = new String[s.length()];
					sa[i] = Character.toString(s.charAt(i));
					sb.append(sa[i]);
					flag = false;
				}
			}
			if (flag) {
				String s1 = Main.getMiddleChars(s);
				System.out.println("Middle characters:\n" + s1);
			} else
				System.out.println("The string should not have " + sb);
		} else
			System.out.println("The string " + s + " is too short");
    }
    	public static String getMiddleChars(String str) {
		StringBuffer sb = new StringBuffer();
		if (str.length() % 2 == 0) {
			sb.append(str.substring((str.length() / 2) - 1, (str.length() / 2) + 1));
		} else {
			sb.append(str.substring((str.length() / 2), (str.length() / 2) + 1));
		}
		return sb.toString();
	}
	
}