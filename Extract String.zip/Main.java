

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine().toLowerCase();
		sc.close();
		if(input.length()<2)
		{
			System.out.println("Length of the string "+input+" is too low");
			sc.close();
			return;
		}
		else if(input.length()>10)
		{
			System.out.println("Length of the string "+input+" is too high");
			sc.close();
			return;
		}
		char[] data=input.toCharArray();
		stringCheck(data);
		char[] sub=input.substring(input.length()/2).toCharArray();
		sub[0]=(char) (sub[0]-32);
	System.out.println(String.valueOf(sub));
		
		
	}

	

	public static void stringCheck(char[] data)
	{ 	ArrayList<Character> list=new ArrayList<Character>();
		for (int i = 0; i < data.length; i++) {
			if(data[i]>=65 && data[i]<=90   || data[i]>=97 && data[i]<=122 || data[i]==' ')
			{
			continue;
			}
			else {
				list.add(data[i]);
			}
		}
		 if(list.size()>0)
		 {
			 System.out.print(String.valueOf(data)+" is Invalid");
			System.exit(0);
		 }	}
}
