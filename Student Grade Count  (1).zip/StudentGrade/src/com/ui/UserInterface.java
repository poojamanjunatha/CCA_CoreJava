
package com.ui;

import com.utility.*;

import java.util.*;

public class UserInterface {
public static void main(String[] args) {
// Type your code here
int choice = 1;
StudentBO sbo = new StudentBO();
Scanner sc = new Scanner(System.in);

while (choice ==1) {
System.out.println("1. Add student details");
System.out.println("2. Find count of students");
System.out.println("3. Exit");

System.out.println("Enter your choice");
choice = sc.nextInt();

if (choice < 1 || choice > 3) {
return;
} else if(choice==1){
sc.nextLine();
System.out.println("Enter the student roll number");
String rollNumber = sc.next();

System.out.println("Enter the grade Secured");
char securedGrade = sc.next().charAt(0);

sbo.addStudentDetails(rollNumber, securedGrade);
}

}

if (choice == 2) {

System.out.println("Enter the grade to find the count of students");
char grade = sc.next().charAt(0);
int countOfStudent =sbo.findCountofStudents(grade);

if(countOfStudent==0) {
System.out.println("No students found");
}else {
System.out.println(countOfStudent);
}


int choice1 = 0;
while (choice1 == 1) {
System.out.println("1. Add student details");
System.out.println("2. Find count of students");
System.out.println("3. Exit");

System.out.println("Enter your choice");
choice1 = sc.nextInt();

if (choice1 == 3) {
System.out.println("Thank you for using the application");
return;
} else {
return;
}

}
} else if (choice == 3) {
System.out.println("Thank you for using the application");
return;
}

}
}


