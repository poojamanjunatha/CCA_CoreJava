package com.utility;
import com.ui.*;
import java.util.*;
import java.util.stream.Stream;

public class StudentBO {

private Map<String, Character> studentMap = new HashMap<String, Character>();

public Map<String, Character> getStudentMap() {
return studentMap;
}

public void setStudentMap(Map<String, Character> studentMap) {
this.studentMap = studentMap;
}

// This method should add the rollNumber as key and their grades as value into a
// Map
public void addStudentDetails(String rollNumber, char securedGrade) {
studentMap.put(rollNumber, securedGrade);
}

/*
* This method should return the count of students secured the grade which is
* passed as the argument. For example: If the map contains the key and value
* as: AE1548 A AE1549 A AE1512 C
*
* if the grade is A the output should be 2
*/
public int findCountofStudents(char grade) {
int count = 0;
// type your logic here
// for(int i=0;i<studentMap.size();i++) {
// if(studentMap.==grade) {
// count++;
// }
// }

List list=new ArrayList(studentMap.values());

for(int i=0;i<list.size();i++) {
if(list.get(i).equals(grade)) {
count++;
}
}




return count;
}

}
