
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Company {
	
	Statement stmt= null;
	public Employee viewEmployee(int eid) throws ClassNotFoundException, SQLException
	{
	    //fill the logic to retrieve the employee details from the employee data base and return employee object
		Employee empObj = new Employee();

		String query = "select * from employee where empId =" + eid + ";";

		stmt = DB.getConnection().createStatement();
		ResultSet result = stmt.executeQuery(query);

		while (result.next()) {
			empObj.setEmpId(result.getInt(1));
			empObj.setEmpName(result.getString(2));
			empObj.setExperience(result.getInt(3));

		}
		DB.getConnection().close();
		return empObj;
	}
}
