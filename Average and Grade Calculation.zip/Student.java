public class Student {

	private int id;
	private String name;
	private int[] marks;
	private float average;
	private char grade;
	
	public Student(int id, String name, int[] marks) {
		this.id=id;
		this.name=name;
		this.marks=marks;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int[] getMarks() {
		return marks;
	}
	public void setMarks(int[] marks) {
		this.marks = marks;
	}
	public float getAverage() {
		calculateAvg();
		return average;
	}
	public void setAverage(float average) {
		this.average = average;
	}
	public char getGrade() {
		findGrade();
		return grade;
	}
	public void setGrade(char grade) {
		this.grade = grade;
	}
	
	public void calculateAvg() {
		float avg=0;
		int[] m=getMarks();
		for (int i = 0; i < m.length; i++) {
			avg=avg+m[i];
			}
		avg=avg/m.length;
		setAverage(avg);
		
	}
	
	public void findGrade() {
		int[] m=getMarks();
		boolean f=false;
		for (int i = 0; i < m.length; i++) {
			if(m[i]<50)
			{
				setGrade('F');
				f=true;
				break;
			}
		}
		if(!f) {
		if(getAverage()>=80)
			setGrade('O');
		else 
			setGrade('A');
	}
	}
	
}
