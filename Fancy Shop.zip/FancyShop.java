//import the necessary packages if needed
import java.util.Scanner;
import java.util.TreeMap;
@SuppressWarnings("unchecked")//Do not delete this line


public class FancyShop {

	public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	TreeMap<Integer, String> ma=new TreeMap<Integer, String>();
	System.out.println("Enter the no of Face Creams you want to store:");
	int c=sc.nextInt();
	for (int i = 1; i <= c; i++) {
		System.out.println("Enter the key "+i);
		int key=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the value "+i);
		String value=sc.nextLine();
		ma.put(key, value);
	}
	sc.close();
	System.out.println("Face Cream Details");
	ma.forEach((key,value)->{
		System.out.println(key + " "+value);	
	});

	}
}
