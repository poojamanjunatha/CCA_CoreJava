import java.util.Scanner;

class Main {

public static void main(String[] args) {
int count1 = 0;
String[] s1;
String[] s2;
char slot ;
int slotNum;
int count2=0;

Scanner sc = new Scanner(System.in);
System.out.println("Enter a number from the slot");

slotNum = sc.nextInt();
if (slotNum < 5 || slotNum > 15) {
System.out.println(slotNum + " is not a valid slot number");
return;
} else if (slotNum >= 5 || slotNum <= 15) {
System.out.println("Enter the " + slotNum + " customer names");
s1 = new String[slotNum];
for (int m = 0; m < slotNum; m++) {
s1[m] = sc.next();
}

System.out.println("Enter the alphabet from the slot");
slot = sc. next(). charAt(0);
s2 = new String[slotNum];
for (int i = 0; i < s1.length; i++) {
int count = 0;

for (int j = 0; j < s1[i].length(); j++) {

if (Character.toLowerCase(s1[i].charAt(j))== Character.toLowerCase(slot)) {

s2[i]=s1[i];
count2++;

break;

} else {
count++;
}

}
if (count == s1[i].length()) {
count1++;
}
}
if (count1 == s1.length) {
System.out.println("Letter "+slot+" is not present in any of the customer's name");
}else {
System.out.println("Customers List");

for(int l=0;l<slotNum;l++) {

if(s2[l] != null ) {
System.out.println(s2[l]);
}else {
continue;
}
}
}

}

}
}