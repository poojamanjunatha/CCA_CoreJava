import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TestMain {
	
public static void main(String[] args) throws NumberFormatException, IOException {
	Student s=createStudent();
	System.out.println("Department id:"+s.getDepartment().getDid());
	System.out.println("Department name:"+s.getDepartment().getDname());
	System.out.println("Student id:"+s.getSid());
	System.out.println("Student name:"+s.getSname());
}

public static Student createStudent() throws NumberFormatException, IOException {
	Student s=null;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the Department id:");
	int did=Integer.parseInt(br.readLine());

	System.out.println("Enter the Department name:");
	String dname=br.readLine();
	
	System.out.println("Enter the Student id:");
	int sid=Integer.parseInt(br.readLine());
	
	System.out.println("Enter the Student name:");
	String sname=br.readLine();
	s=new Student();
	s.setSid(sid);
	s.setSname(sname);
	Department d=new Department();
	d.setDid(did);
	d.setDname(dname);
	s.setDepartment(d);
	
	return s;
}
}
