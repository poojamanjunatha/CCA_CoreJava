import java.util.Scanner;

public class Call {
	
	
private int callId;
private long calledNumber;
private float duration;

public int getCallId() {
	return callId;
}
public void setCallId(int callId) {
	this.callId = callId;
}
public long getCalledNumber() {
	return calledNumber;
}
public void setCalledNumber(long calledNumber) {
	this.calledNumber = calledNumber;
}
public float getDuration() {
	return duration;
}
public void setDuration(float duration) {
	this.duration = duration;
}

public void parseData(String s)
{
String[] det=s.split(":");
setCallId(Integer.parseInt(det[0]));
setCalledNumber(Long.parseLong(det[1]));
setDuration(Float.parseFloat(det[2]));


}
}
