import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	static Ticket t=null;
	static int numberofbooking;
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter no of bookings:");
		numberofbooking=Integer.parseInt(br.readLine());
		
		System.out.println("Enter the available tickets:");
		int atick=Integer.parseInt(br.readLine());
		Ticket.setAvailableTickets(atick);
		booking();
			
	}
	
public static void booking() throws NumberFormatException, IOException
{
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the ticketid:");
	int tid=Integer.parseInt(br.readLine());

	System.out.println("Enter the price:");
	int pr=Integer.parseInt(br.readLine());
	
	System.out.println("Enter the no of tickets:");
	int no=Integer.parseInt(br.readLine());	
	
	for (int i = 1; i <=numberofbooking ; i++) {
		t=new Ticket();
		t.setPrice(pr);
		t.setTicketid(tid);
		ticket(no);
		booking();
		i++;
	}
	}


public static void ticket(int nobook)
{
	
	System.out.println("Available tickets:"+Ticket.getAvailableTickets());
	System.out.println("Total amount:"+t.getPrice()*nobook);
	Ticket.setAvailableTickets(Ticket.getAvailableTickets()-nobook);
	System.out.println("Available ticket after booking:"+Ticket.getAvailableTickets());
}
}
