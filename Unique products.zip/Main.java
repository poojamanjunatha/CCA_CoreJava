import java.util.Scanner;

class Main{
   
    public static void main (String[] args) {
       
        int noOfItems;
        int[] barcode;
        int[] barcode1;
        int[] barcode2;
       
        Scanner sc = new Scanner(System.in);
       
        System.out.println("Enter the number of items:");
        noOfItems = sc.nextInt();
       
        if(noOfItems<5||noOfItems>20){
            System.out.println(noOfItems+" is an invalid item count");
            return;
        }
       
        System.out.println("Enter the bar code ID for "+noOfItems+" items:");
        barcode = new int[noOfItems];
        barcode1= new int[noOfItems];
        barcode2= new int[noOfItems];
        for(int i =0;i<noOfItems;i++){
            barcode[i] = sc.nextInt();
            barcode1[i]=barcode[i];
            barcode2[i]=barcode[i];
            int count =0;
            while(barcode[i]>0){
               
                barcode[i]=barcode[i]/10;
                ++count;
               
            }
            if(count!=3){
                System.out.println(barcode1[i]+" is an invalid bar code ID");
                return;
            }
           
        }
        int[] a2= new int[50]; int l=0;
        for(int m=0;m<noOfItems;m++) {
       
        int[] a=new int[100]; int n=0;
          while(barcode1[m]>0) {
          a[n]=(barcode1[m]%10);
          n++;
          barcode1[m]=barcode1[m]/10;
         
          }
       
          int count1=0; int count2=0;
        for(int j=0;j<n;j++) {
       for(int k=j+1;k<n;k++) {
       if(a[j]==a[k]) {
       count1++;
       }
             
       }
       
       
        }
        if(count1>0) {
   
   }else {
 
System.out.println(barcode2[m]);

l++;
   }
         
       
        }
        if(l==0) {
        System.out.print("There are no items with Unique number in ");
        for(int g=0;g<noOfItems;g++) {
        System.out.print(barcode2[g]+",");
        }
       
        }else {
       System.out.println("There are "+l+" items with Unique number in the bar code ID");
        }
    }
   
}
