import java.util.*;
public class Main 
    {
        public static void main(String[] args)
        {
            Scanner sc=new Scanner(System.in);
            
            
            // Fill the code


		String s = sc.next();
		if (!Main.check(s)) {
			if (s.length() >= 3) {
				if (s.length() <= 10) {
					StringBuffer sb = new StringBuffer(s);
					char ch = sc.next().charAt(0);
					boolean flag = false;
					for (int i = 0; i < s.length(); i++) {
						char c = s.charAt(i);
						if (Character.isLetter(s.charAt(i))) {
							if (Character.toLowerCase(ch) == c || Character.toUpperCase(ch) == c) {
								flag = true;
								if (Character.isUpperCase(s.charAt(i))) {
									sb.setCharAt(i, Character.toLowerCase(s.charAt(i)));
								} else if (Character.isLowerCase(s.charAt(i))) {
									sb.setCharAt(i, Character.toUpperCase(s.charAt(i)));
								}
							}
						}
					}
					if (flag == true)
						System.out.println(sb);
					else
						System.out.println("Character not found");
				} else {
					System.out.println("String length of " + s.length() + " is too long");
				}
			} else {
				System.out.println("String length of " + s.length() + " is too short");
			}
		}
	}     
      public static boolean check(String st) {
		boolean flag = false;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < st.length(); i++) {
			if (!Character.isLetter(st.charAt(i))) {
				String[] sa = new String[st.length()];
				sa[i] = Character.toString(st.charAt(i));
				sb.append(sa[i]);
				flag = true;
			}
		}
		if (flag) {
			System.out.println("String should not contain " + sb);
		}
		return flag;
    }
}