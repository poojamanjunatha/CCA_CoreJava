package com.ui;

import com.utility.*;



import java.util.*;

public class UserInterface
{

public static void main(String[] args)
{
//Type you logic here

int choice = 1;
GradeBO gbo= new GradeBO();
GradeBO gbo1 = new GradeBO();
Scanner sc = new Scanner(System.in);

while (choice == 1) {
System.out.println("1. Add GradePoint");
System.out.println("2. Calculate GPA");
System.out.println("3. Exit");

System.out.println("Enter your choice");
choice = sc.nextInt();

if (choice < 1 || choice > 3) {
return;
} else if (choice == 1) {
sc.nextLine();
System.out.println("Enter the gradePoint scored");
int gradePoint = sc.nextInt();

gbo.addGradeDetails(gradePoint);

}

}

if (choice == 2) {
int grade = (int) gbo.getGPAScored();

if (grade == 0) {
System.out.println("No GradePoints available");

} else {
System.out.println("GPA Scored\n"+grade);

int choice1 = 1;
while (choice1 == 1) {
System.out.println("1. Add GradePoint");
System.out.println("2. Calculate GPA");
System.out.println("3. Exit");

System.out.println("Enter your choice");
choice1 = sc.nextInt();

if (choice1 < 1 || choice1 > 3) {
return;
} else if (choice1 == 1) {
sc.nextLine();
System.out.println("Enter the gradePoint scored");
int gradePoint1 = sc.nextInt();

gbo1.addGradeDetails(gradePoint1);

}
}
if(choice1==2) {


int grade1 = (int) gbo1.getGPAScored();

if (grade1 == 0) {
System.out.println("No GradePoints available");

} else {
System.out.println("GPA Scored\n"+grade1);

int choice2 = 1;
while (choice2 == 1) {

System.out.println("1. Add GradePoint");
System.out.println("2. Calculate GPA");
System.out.println("3. Exit");

System.out.println("Enter your choice");
choice2 = sc.nextInt();
}

if (choice2 == 3) {
System.out.println("Thank you for using the application");
return;
} else {
return;
}

}
}
if (choice1 == 3) {
System.out.println("Thank you for using the application");
return;
} else {
return;
}


}

} else if (choice == 3) {
System.out.println("Thank you for using the application");
return;
}





}

}

