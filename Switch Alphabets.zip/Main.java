import java.util.*;
public class Main {
public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();

		char[] ch = input.toCharArray();
		int count = 0;
		for (int i = 0; i < ch.length; i++) {
			if (ch[i] == 'a' || ch[i] == 'e' || ch[i] == 'i' || ch[i] == 'o' || ch[i] == 'u') {
				ch[i] = '#';
				count++;
			}

		}
		sc.close();
		if (count == 0)
			System.out.println(input + " has no vowels");
		else
			System.out.println(new String(ch));
	}
}
