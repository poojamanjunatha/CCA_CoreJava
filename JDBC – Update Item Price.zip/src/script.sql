drop table if exists item;

Create table item

(

Id varchar(10),


name varchar(15) not null,


price double not null,


Primary key(id)


);


insert into item (id,name,price) values ('001','Television',30000.0);


insert into item (id,name,price) values ('002','Mobile Phone',15000.0);


insert into item (id,name,price) values ('003','Laptop',40000.0);


insert into item (id,name,price) values ('004','Furniture',50000.0);


insert into item (id,name,price) values ('005','Refrigerator',25000.0);







