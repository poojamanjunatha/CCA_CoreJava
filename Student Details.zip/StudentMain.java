
import java.io.IOException;
import java.util.Scanner;

public class StudentMain {
	
	public static void main(String args[]) throws NumberFormatException, IOException {

		StudentMain s1=new StudentMain();
		
		Student s = s1.getStudentDetails();
		System.out.println("Student id:" + s.getStudentId()); 
		System.out.println("Student name:" + s.getStudentName());
		System.out.println("Address:" + s.getStudentAddress());
		System.out.println("College name:" + s.getCollegeName());
	}

	public static Student getStudentDetails() throws NumberFormatException, IOException {
		Student s = null;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Student's Id:");
		int id = scanner.nextInt();

		System.out.println("Enter Student's Name:");
		String name = scanner.next();

		System.out.println("Enter Student's address:");
		String address = scanner.next();
		String status = null;
		int flag = 0;
		do {
			System.out.println("Whether the student is from NIT(Yes/No):");
			status = scanner.next();
			flag = 0;
			if (!(status.equalsIgnoreCase("yes") || status.equalsIgnoreCase("no"))) {
				System.out.println("Wrong Input");
				flag = 1;
			}
		} while (flag == 1);
		if (status.equalsIgnoreCase("no")) {
			System.out.println("Enter the college name:");
			String college = scanner.next();
			s = new Student(id, name, address, college);
		} else if (status.equalsIgnoreCase("yes")) {
			s = new Student(id, name, address);
		}
		return s;

	}
}
