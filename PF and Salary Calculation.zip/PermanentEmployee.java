public class PermanentEmployee extends Employee {

	private float pfpercentage;
	private float pfamount;

	public float getPfpercentage() {
		return pfpercentage;
	}

	public void setPfpercentage(float pfpercentage) {
		this.pfpercentage = pfpercentage;
	}

	public float getPfamount() {
		return pfamount;
	}

	public void setPfamount(float pfamount) {
		this.pfamount = pfamount;
	}

	public void findNetSalary() {
		
		setPfamount(getSalary()/100*getPfpercentage());
		setNetsalary(getSalary()-getPfamount());
	}

	public boolean validateInput(float salary, float pfPercentage) {
		
		boolean flag = false;
		if (salary <= 0 || pfPercentage < 0) {
			flag = false;
		} else if (salary > 0 || pfPercentage >= 0) {
			return true;
		}
		return flag;
	}
}

