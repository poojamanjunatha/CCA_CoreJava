import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("#,###,##0.0");
		System.out.println("Enter the name:");
		String name = sc.nextLine();

		System.out.println("Enter the salary:");
		float salary = sc.nextFloat();

		System.out.println("Enter the pfpercentage:");
		float pfPercentage = sc.nextFloat();

		boolean validation;
		PermanentEmployee peObj = new PermanentEmployee();
		validation = peObj.validateInput(salary, pfPercentage);
		peObj.setPfpercentage(pfPercentage);
		peObj.setSalary(salary);
		
		if (validation == true) {
			peObj.findNetSalary();
			System.out.println("Employee Name:"+name);
			System.out.println("PF Amount:"+peObj.getPfamount());
			System.out.println("Netsalary:"+peObj.getNetsalary());
		} else {
			System.out.println("Error!!! Unable to calculate the NetSalary.");
		}
	}
}

