
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		int noofcargo;
		
		List<Cargo> list=new ArrayList<>();
		
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("Enter the number of Cargo:");
		noofcargo=sc.nextInt();
		
		System.out.println("Enter cargo details (id,length,width,weight,cargo type,storage type):");

		
		for(int i=0;i<noofcargo;i++){
			
			
			String cargodetails=sc.next();
			
			String ar[]=cargodetails.split(",");
			
			Cargo cargo1=new Cargo(Long.valueOf(ar[0]),Integer.valueOf(ar[1]) ,Integer.valueOf(ar[2]), Integer.valueOf(ar[3]), ar[4], ar[5]);
			
			
			list.add(cargo1);
			
		}
		
		ShippingCostThread shippingCostThread=new ShippingCostThread();
		List<Double> list2=new ArrayList<Double>();
		for(Cargo cargo:list){
			double price=0.0;
			if("DRY".equals(cargo.getStorageType())){
				 price=((cargo.getWeight())*0.90);
			}
			if("COLD".equals(cargo.getStorageType())){
				 price=((cargo.getWeight())*1.85);
			}
			
			list2.add(price);
			
		}
		
		shippingCostThread.setCargoList(list);
		shippingCostThread.setPriceList(list2);
		
		
		System.out.println("Price List:");
		
		shippingCostThread.start();
		
		
		
		
		

		

	}

}
