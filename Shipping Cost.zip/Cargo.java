public class Cargo {

	private	Long id;
	private	Integer length;
	private	Integer width;
	private	Integer weight;
	private	String cargoType;
	private	String storageType;
	private	static String DRY_STORAGE;
	private	static String COLD_STORAGE;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Integer getLength() {
			return length;
		}
		public void setLength(Integer length) {
			this.length = length;
		}
		public Integer getWidth() {
			return width;
		}
		public void setWidth(Integer width) {
			this.width = width;
		}
		public Integer getWeight() {
			return weight;
		}
		public void setWeight(Integer weight) {
			this.weight = weight;
		}
		public String getCargoType() {
			return cargoType;
		}
		public void setCargoType(String cargoType) {
			this.cargoType = cargoType;
		}
		public String getStorageType() {
			return storageType;
		}
		public void setStorageType(String storageType) {
			this.storageType = storageType;
		}
		public static String getDRY_STORAGE() {
			return DRY_STORAGE;
		}
		public static void setDRY_STORAGE(String dRY_STORAGE) {
			DRY_STORAGE = dRY_STORAGE;
		}
		public static String getCOLD_STORAGE() {
			return COLD_STORAGE;
		}
		public static void setCOLD_STORAGE(String cOLD_STORAGE) {
			COLD_STORAGE = cOLD_STORAGE;
		}
		public Cargo(Long id, Integer length, Integer width, Integer weight, String cargoType, String storageType) {
			super();
			this.id = id;
			this.length = length;
			this.width = width;
			this.weight = weight;
			this.cargoType = cargoType;
			this.storageType = storageType;
		}
		
		


}
