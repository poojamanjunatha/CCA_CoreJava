import java.util.List;



public class ShippingCostThread extends Thread {
		List<Cargo> cargoList;
		List<Double> priceList;
		public List<Cargo> getCargoList() {
			return cargoList;
		}
		public void setCargoList(List<Cargo> cargoList) {
			this.cargoList = cargoList;
		}
		public List<Double> getPriceList() {
			return priceList;
		}
		public void setPriceList(List<Double> priceList) {
			this.priceList = priceList;
		}

		public void  run() {
			 for(Double i :priceList){
				 
				 System.out.println(i);
				 
				 
			 }
				
		}
		
		
}
