package com.ui;

import com.utility.*;

import java.util.*;

public class UserInterface {

public static void main(String[] args) {
int choice=1;

List<Integer> list;
list = new ArrayList<Integer>();
PlayerBO pbo = new PlayerBO();
int i =0;
Scanner sc =new Scanner(System.in);
//Fill the UI code

while(choice==1) {
System.out.println("1. Add overs bowled");
System.out.println("2. Number of balls bowled");
System.out.println("3. Exit");

System.out.println("Enter your choice");

choice = sc.nextInt();
if(choice<1||choice>3) {
return;
}else

if(choice==1) {
System.out.println("Enter the overs bowled");
int oversBowled= sc.nextInt() ;

// list.add(oversBowled);
// i++;

pbo.addOversDetails(oversBowled);

}

}

if(choice==2) {
// for(int j=0;j<list.size();j++) {
// System.out.println(list.get(j));
// }
// pbo.setPlayerList(list);

System.out.println("Total number of balls bowled\n"+pbo.getNoOfBallsBowled());


int choice2=1;
while(choice2==1) {
System.out.println("1. Add overs bowled");
System.out.println("2. Number of balls bowled");
System.out.println("3. Exit");

System.out.println("Enter your choice");

choice2 = sc.nextInt();
if(choice2==3) {
System.out.println("Thank you for using the application");
return;
}else {
return;
}



}


}else if(choice ==3) {
System.out.println("Thank you for using the application");
return;
}



}

}

