import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Main {
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
            // Type your logic here
              System.out.println("Enter the number of login attempts");
            int choice = sc.nextInt();
            UserDAO u=new UserDAO();
            u.makeInActive(choice);
            u.getInActiveUsers();
        sc.close();
         
           
        }

 

}
