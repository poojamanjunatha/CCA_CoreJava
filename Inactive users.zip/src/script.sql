drop table if exists user;

Create table user
(
Id int not null auto_increment,
Username varchar(15) not null,
Address varchar(20) not null,
Mobilenumber varchar(20) not null,
Failedattempts int not null,
Deleted int,
Primary key(id)
);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Jacklyn','California', 9871321470,5,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('John','California', 8203145712,5,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Kasia','California', 9785413216,6,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Lucy','Texas', 8299995712,6,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Bailey','California', 7896412006,5,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Corrine','Erode', 8203145713,5,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Dianne','Alaska', 8209531712,5,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Faye','California', 9873145712,7,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Greta','Alaska', 8203145712,5,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Ida','Chennai', 90000000150,5,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Maxwell','Texas', 8299945712,6,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Nellie','Canada', 8205555745,7,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Queeny','Alaska', 8205555712,7,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Natie','Alaska', 9605555712,9,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Deanne','Canada', 9505555712,9,0);
insert into user (Username,Address,Mobilenumber,Failedattempts,deleted) values ('Penelope','Erode', 7405555712,10,0);
