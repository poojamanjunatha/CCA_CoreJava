import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		int noofmembers;
		
		
		List<Member> list=new ArrayList<Member>();
		List<ZEEShop> list2=new ArrayList<ZEEShop>();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of Members:");
		noofmembers=sc.nextInt();
		
		
		for(int i=0;i<noofmembers;i++){
			System.out.println("Enter the Member Details:");
			String memeberdetail=sc.next();
			
			String[] ar=memeberdetail.split(":");
			
			Member member=new Member(ar[0], ar[1], ar[2]);
			list.add(member);
			
			
		}
		
		
		System.out.println("Enter the number of times Membership category needs to be searched:");
		int count=sc.nextInt();
		
		for(int i=0;i<count;i++){
			System.out.println("Enter the Category");
			String cat=sc.next();
			ZEEShop zeeShop=new ZEEShop(cat, list);
			
			
			
			list2.add(zeeShop);
			
		}
		
		
		
		for(ZEEShop z: list2){
	        z.start();
	        try {z.join();} catch (InterruptedException e) {e.printStackTrace();}
	    }
		
		
		
		
		
	}

}
