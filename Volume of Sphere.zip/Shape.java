public abstract class Shape {
	public Shape() {
	}
	public abstract double calculateVolume();
}

