import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		int radius;

		Scanner sc = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("#,###,##0.0");

		System.out.println("Enter radius:");
		radius = sc.nextInt();

		Sphere spObj = new Sphere(radius);

		System.out.println("Volume of Sphere is " + df.format(spObj.calculateVolume()));

	}
}

