public class Sphere extends Shape {

	private int radius;

	public Sphere() {
		super();
	}

	public Sphere(int radius) {
		super();
		this.radius = radius;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	public double calculateVolume() {

		double val = Double.valueOf(4) / Double.valueOf(3);
		double volume = val * Math.PI * (radius * radius * radius);
		return volume;
	}
}

