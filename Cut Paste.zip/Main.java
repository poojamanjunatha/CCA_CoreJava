import java.util.Scanner;

public class Main{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String:");
		String input=sc.nextLine();
		
		System.out.println("Position:");
		int position=sc.nextInt();
		sc.close();
		if(position<1)
		{
			System.out.println("String cannot contain Position "+position);
				return;
		}
		else if(position>input.length())
		{
			System.out.println("Position exceeds the string "+input);
			return;
		}
			
	String s=input.substring(0,position-1)+input.substring(position,input.length());
	System.out.println(s);
		
		
	}

	

}
