import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;




public class Main {
    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
        BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
        // Fill the code here
   
        FileReader fr = new FileReader(new File("script.sql"));
        String s = new String();
        StringBuffer sb = new StringBuffer();
        BufferedReader br = new BufferedReader(fr);


        while ((s = br.readLine()) != null) {
            sb.append(s);
        }
        br.close();
        String[] inst = sb.toString().split(";");


        Connection con = DbConnection.getConnection();
        Statement stmnt1 = con.createStatement();


        for (int i = 0; i < inst.length; i++) {
            if (!inst[i].trim().equals("")) {
                stmnt1.executeUpdate(inst[i]);
            }
        }
       
        UserDAO d=new UserDAO();
        ArrayList<Contact> c=new ArrayList<Contact>();
        ArrayList<User> use=new ArrayList<User>();
        int k=1, m=0,l=0;;
        do{
            System.out.println("Enter user " + k++ + " detail");
            String userdetail = b.readLine();


            String[] usr=userdetail.split(",");
            Statement stmnt2 = con.createStatement();
            stmnt2.executeUpdate("insert into contact (mobilenumber,emailid) values('"+usr[4]+"','"+usr[5]+"');");
           
            ResultSet res = stmnt2.executeQuery("select Id from contact where mobilenumber='"+usr[4]+"';");
            res.next();
            int id=res.getInt("Id");
           
            c.add(new Contact(id,usr[4], usr[5]));
            use.add(new User(id, usr[0], usr[1], usr[2], usr[3], c.get(l)));
            d.createUser(use.get(l));
           
            l++;
            System.out.println("Do you want to create another user?(yes/no)");
            String check = b.readLine();
                       
            if (!check.equalsIgnoreCase("yes"))
            {
                m=1;
                break;}
        }while(m==0);
       
        System.out.println("Enter the first name to search:");
        String name = b.readLine();
        List<User> details = d.findByFirstName(name);
       
        System.out.println("User details are");
        System.out.println("Id Firstname Lastname Mobilenumber Email ID");
       
        for (int i = 0; i < details.size(); i++) {
            System.out.println(details.get(i).getId()+" "+details.get(i).getFirstName()+" "+details.get(i).getLastName()+" "+details.get(i).getContact().getMobileNumber()+" "+details.get(i).getContact().getEmailId());
           
        }
    }
}
 


