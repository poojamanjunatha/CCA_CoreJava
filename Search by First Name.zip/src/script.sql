drop table if exists contact;
Create table contact


(


Id int not null auto_increment,


mobilenumber varchar(15) not null,


emailid varchar(25),


Primary key(id)


);





drop table if exists user;


Create table user


(


Id int not null auto_increment,


username varchar(15) not null,


firstname varchar(15) not null,


lastname varchar(15) not null,


password varchar(25) not null,


contact_id int references contact(id),


Primary key(id)


);












