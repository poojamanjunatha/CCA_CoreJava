public class Contact
{
    private Integer id;
    private String mobileNumber;
    private String emailId;
   
    public Contact( Integer id,String mobileNumber,String emailId) {
        this.id=id;
        this.mobileNumber=mobileNumber;
        this.emailId=emailId;
    }
   
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getMobileNumber() {
        return mobileNumber;
    }
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }
    public String getEmailId() {
        return emailId;
    }
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }


}
 


