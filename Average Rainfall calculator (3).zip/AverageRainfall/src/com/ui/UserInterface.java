package com.ui;

import com.utility.*;
import java.util.*;

public class UserInterface 
{

		public static void main(String[] args)
		{
			Scanner sc =new Scanner(System.in);
			//Type your logic here
			RMCBO r = new RMCBO();
		boolean b = true;
		while (b) {
			System.out.println("1. Add rainfall details\n2. Average Rainfall occurred\n3. Exit");
			System.out.println("Enter your choice");
			int n = sc.nextInt();
			switch (n) {
			case 1:
				System.out.println("Enter the Date");
				String date = sc.next();
				System.out.println("Enter the recorded rainfall in mm");
				int mm = sc.nextInt();
				r.addRainfallDetails(mm);
				break;

			case 2:
				
				double result = r.findAverageRainfallOccured();
				if (result != 0)
				{
					System.out.println("Average Rainfall recorded in mm");
					System.out.println(result);
				}
				else
					System.out.println("No records found");
				break;

			case 3:
				System.out.println("Thank you for using the Application");
				b = false;
				break;

			default:
				break;
			}
		}

		}

	}

