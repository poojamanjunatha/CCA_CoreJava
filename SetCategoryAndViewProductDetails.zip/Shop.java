import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Shop {
	
	public Product viewProduct(int pid)
	{
		Product p=null;
		try {
		Connection con = DB.getConnection();
		 Statement stmnt = con.createStatement();
	//fill the logic to retrive the product details from database and return product object
		 ResultSet set = stmnt.executeQuery("select * from product where prodId='"+pid+"';");
		 while(set.next())
		 {
			 p=new Product();
			 p.setProdId(pid);
			 p.setProdName(set.getString("prodName"));
			 p.setUnitPrice(set.getDouble("prodPrice"));
		 }
	    return p;}
		catch (Exception e) {
			// TODO: handle exception
		System.out.println(e.getMessage());
		 return p;
		}
		
	}
	
}
